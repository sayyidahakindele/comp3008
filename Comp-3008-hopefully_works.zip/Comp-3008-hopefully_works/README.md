# Comp-3008

In terminal 
$ cd MyWebApp
$ dotnet watch


IF YOU GET THE GIT ERROR INSTEAD OF DELECTING CODESPACE 
TRY THIS FIRST 
git config --global  pull.ff true

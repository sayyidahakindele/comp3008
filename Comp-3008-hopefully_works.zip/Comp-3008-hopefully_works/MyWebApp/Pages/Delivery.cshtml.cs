// using Microsoft.AspNetCore.Mvc;
// using Microsoft.AspNetCore.Mvc.RazorPages;

// namespace MyWebApp.Pages;

// public class DeliveryModel : PageModel
// {
//     private readonly ILogger<DeliveryModel> _logger;

//     public IndexModel(ILogger<DeliveryModel> logger)
//     {
//         _logger = logger;
//     }

//     public void OnGet()
//     {

//     }
// }

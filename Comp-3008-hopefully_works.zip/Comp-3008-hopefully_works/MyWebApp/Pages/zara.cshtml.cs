// using Microsoft.AspNetCore.Mvc;
// using Microsoft.AspNetCore.Mvc.RazorPages;

// namespace MyWebApp.Pages;

// public class ZaraModel : PageModel
// {
//      private readonly ILogger<LoginModel> _logger;

//     public LoginModel(ILogger<LoginModel> logger)
//     {
//         _logger = logger;
//     }

//     public void OnGet()
//     {

//     }

//     [BindProperty]
//     public string Username { get; }

// }